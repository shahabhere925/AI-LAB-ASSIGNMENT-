
from collections import deque



pakistan_graph = {
    "Islamabad" : ["Rawalpindi", "Lahore", "Peshawar"],
    "Rawalpindi": ["Islamabad",  "Peshawar", "Quetta"],
    "Peshawar"  : ["Islamabad",  "Rawalpindi", "Quetta"],
    "Lahore"    : ["Islamabad",  "Multan", "Quetta"],
    "Multan"    : ["Lahore",     "Karachi", "Quetta"],
    "Quetta"    : ["Rawalpindi", "Peshawar", "Multan", "Karachi"],
    "Karachi"   : ["Multan",     "Quetta"],
}



def bfs_shortest_path(graph, start, goal):
    """
    BFS guarantees the shortest path in terms of
    number of cities (hops) between start and goal.
    """
    visited = set()
    queue   = deque([[start]])          

    print(f"\n{'='*55}")
    print(f"  BFS: Shortest route from '{start}' to '{goal}'")
    print(f"{'='*55}")

    while queue:
        path = queue.popleft()
        node = path[-1]

        if node in visited:
            continue

        visited.add(node)
        print(f"  Exploring: {node:<15}  Path: {' → '.join(path)}")

        if node == goal:
            print(f"\n   Destination '{goal}' reached!")
            return path

        for neighbor in graph.get(node, []):
            if neighbor not in visited:
                queue.append(path + [neighbor])

    print(f"\n   No path found from '{start}' to '{goal}'.")
    return None



def display_graph(graph):
    print("\n" + "="*55)
    print("  PAKISTAN HIGHWAY NETWORK")
    print("="*55)
    for city, connections in graph.items():
        print(f"  {city:<15} ↔  {', '.join(connections)}")



if __name__ == "__main__":
    print("\n" + "="*55)
    print("  TASK 3: Tourist Route — Islamabad to Karachi")
    print("="*55)

    display_graph(pakistan_graph)

    
    path = bfs_shortest_path(pakistan_graph, "Islamabad", "Karachi")

    
    if path:
        print("\n" + "="*55)
        print("  RESULT SUMMARY")
        print("="*55)
        print(f"  Shortest path : {' → '.join(path)}")
        print(f"  Total cities  : {len(path)}")
        print(f"  Total hops    : {len(path) - 1}")
        print("\n  City-by-city breakdown:")
        for i, city in enumerate(path):
            if i == 0:
                print(f"     Start  → {city}")
            elif i == len(path) - 1:
                print(f"     Arrive → {city}")
            else:
                print(f"     Stop {i}  → {city}")

    print("\n  Note: BFS always finds the path with the fewest")
    print("  number of cities, not necessarily the shortest")
    print("  distance in kilometers.")
