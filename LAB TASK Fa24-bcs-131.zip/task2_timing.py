

import random
import time
from collections import deque
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker



def build_tree(data):
    """
    Build an adjacency-list tree from a list.
    Each index i has children at 2i+1 and 2i+2.
    Returns dict: index -> [child_indices]
    """
    n = len(data)
    tree = {}
    for i in range(n):
        children = []
        left  = 2 * i + 1
        right = 2 * i + 2
        if left  < n: children.append(left)
        if right < n: children.append(right)
        tree[i] = children
    return tree



def bfs_tree(tree, start, goal_index):
    visited = set()
    queue = deque([start])
    while queue:
        node = queue.popleft()
        if node in visited:
            continue
        visited.add(node)
        if node == goal_index:
            return True
        for child in tree.get(node, []):
            if child not in visited:
                queue.append(child)
    return False


def dfs_tree(tree, start, goal_index):
    visited = set()
    stack = [start]
    while stack:
        node = stack.pop()
        if node in visited:
            continue
        visited.add(node)
        if node == goal_index:
            return True
        for child in reversed(tree.get(node, [])):
            if child not in visited:
                stack.append(child)
    return False



sizes      = [1_000, 40_000, 80_000, 200_000, 1_000_000]
results    = []

print("="*60)
print("  TASK 2: BFS vs DFS Timing on Large Random Trees")
print("="*60)

for size in sizes:
    print(f"\nDataset size: {size:,}")

    
    data       = random.sample(range(size * 10), size)
    total_len  = len(data)
    goal_index = total_len - 220        

    print(f"  Goal index: {goal_index}  (value: {data[goal_index]})")

    
    tree = build_tree(data)

    
    start_time = time.perf_counter()
    bfs_found  = bfs_tree(tree, 0, goal_index)
    bfs_time   = time.perf_counter() - start_time

    
    start_time = time.perf_counter()
    dfs_found  = dfs_tree(tree, 0, goal_index)
    dfs_time   = time.perf_counter() - start_time

    print(f"  BFS time : {bfs_time:.6f} s  | Found: {bfs_found}")
    print(f"  DFS time : {dfs_time:.6f} s  | Found: {dfs_found}")

    results.append({
        "Dataset Size": size,
        "BFS Time (s)": round(bfs_time, 6),
        "DFS Time (s)": round(dfs_time, 6),
    })



df = pd.DataFrame(results)
print("\n" + "="*60)
print("  RESULTS TABLE")
print("="*60)
print(df.to_string(index=False))



labels     = [f"{s:,}" for s in df["Dataset Size"]]
x          = range(len(labels))
width      = 0.35

fig, ax = plt.subplots(figsize=(12, 6))
bars1 = ax.bar([i - width/2 for i in x], df["BFS Time (s)"], width,
               label="BFS", color="#4C72B0", edgecolor="white")
bars2 = ax.bar([i + width/2 for i in x], df["DFS Time (s)"], width,
               label="DFS", color="#DD8452", edgecolor="white")


for bar in bars1:
    ax.text(bar.get_x() + bar.get_width()/2,
            bar.get_height() + ax.get_ylim()[1]*0.005,
            f"{bar.get_height():.4f}s",
            ha="center", va="bottom", fontsize=8, color="#4C72B0")
for bar in bars2:
    ax.text(bar.get_x() + bar.get_width()/2,
            bar.get_height() + ax.get_ylim()[1]*0.005,
            f"{bar.get_height():.4f}s",
            ha="center", va="bottom", fontsize=8, color="#DD8452")

ax.set_xlabel("Dataset Size (number of elements)", fontsize=12)
ax.set_ylabel("Time Taken (seconds)", fontsize=12)
ax.set_title("BFS vs DFS: Time Comparison Across Dataset Sizes", fontsize=14, fontweight="bold")
ax.set_xticks(list(x))
ax.set_xticklabels(labels, fontsize=10)
ax.legend(fontsize=11)
ax.yaxis.set_major_formatter(ticker.FormatStrFormatter("%.4f"))
ax.grid(axis="y", linestyle="--", alpha=0.5)
plt.tight_layout()
plt.savefig("/mnt/user-data/outputs/task2_bfs_dfs_chart.png", dpi=150)
plt.show()
print("\nChart saved to task2_bfs_dfs_chart.png")
