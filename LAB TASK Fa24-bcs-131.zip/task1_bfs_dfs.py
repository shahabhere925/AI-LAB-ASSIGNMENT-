
from collections import deque


graph = {
    'A': ['B', 'C', 'D'],
    'B': ['A', 'E', 'F'],
    'C': ['A', 'F', 'G'],
    'D': ['A', 'G', 'H'],
    'E': ['B'],
    'F': ['B', 'C'],
    'G': ['C', 'D'],
    'H': ['D']
}


def bfs(graph, start, goal):
    visited = set()
    queue = deque([[start]])          

    print(f"\n{'='*50}")
    print(f"BFS: Finding path from '{start}' to '{goal}'")
    print(f"{'='*50}")

    while queue:
        path = queue.popleft()
        node = path[-1]

        if node in visited:
            continue

        visited.add(node)
        print(f"  Visiting: {node}  |  Path so far: {' -> '.join(path)}")

        if node == goal:
            print(f"\n   Goal '{goal}' found!")
            print(f"  Path: {' -> '.join(path)}")
            return path

        for neighbor in graph.get(node, []):
            if neighbor not in visited:
                queue.append(path + [neighbor])

    print(f"   Goal '{goal}' not found.")
    return None



def dfs(graph, start, goal):
    visited = set()
    stack = [[start]]                 

    print(f"\n{'='*50}")
    print(f"DFS: Finding path from '{start}' to '{goal}'")
    print(f"{'='*50}")

    while stack:
        path = stack.pop()
        node = path[-1]

        if node in visited:
            continue

        visited.add(node)
        print(f"  Visiting: {node}  |  Path so far: {' -> '.join(path)}")

        if node == goal:
            print(f"\n   Goal '{goal}' found!")
            print(f"  Path: {' -> '.join(path)}")
            return path

        for neighbor in reversed(graph.get(node, [])):
            if neighbor not in visited:
                stack.append(path + [neighbor])

    print(f"   Goal '{goal}' not found.")
    return None



if __name__ == "__main__":
    print("\n" + "="*50)
    print("       TASK 1: BFS and DFS on a Graph")
    print("="*50)
    print("\nGraph adjacency list:")
    for node, neighbors in graph.items():
        print(f"  {node}: {neighbors}")

    bfs_path = bfs(graph, 'A', 'H')
    dfs_path = dfs(graph, 'A', 'H')

    print("\n" + "="*50)
    print("SUMMARY")
    print("="*50)
    print(f"  BFS path: {' -> '.join(bfs_path) if bfs_path else 'Not found'}")
    print(f"  DFS path: {' -> '.join(dfs_path) if dfs_path else 'Not found'}")
    print("\nNote: BFS finds the shortest path; DFS may find a longer one.")
